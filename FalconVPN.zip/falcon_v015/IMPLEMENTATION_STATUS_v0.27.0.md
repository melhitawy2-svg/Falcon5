# Falcon VPN v0.27.0 — libbox engine integration (UNTESTED)

## Done
- FalconVpnService now implements libbox PlatformInterface + CommandServerHandler (libbox 1.13.14 signatures, taken from javap output of the actual AAR).
- openTun builds a VpnService tunnel; default-interface monitor, getInterfaces and protect() are implemented.
- State becomes CONNECTED only after CommandServer.startOrReloadService returns without error.
- Config writer adds hijack-dns / sniff rules and a direct DNS resolver for the proxy hostname.
- Dependency switched from the jitpack 1.14.0 pin to app/libs/libbox.aar (1.13.14), fetched by .github/workflows/build.yml.

## Not verified
- This code has NOT been compiled or run on a device. Expect to fix compile errors / runtime issues from the first build and logcat.
- ABI limited to arm64-v8a. Features such as kill switch, split tunneling, auto-connect are not implemented.

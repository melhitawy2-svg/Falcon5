package com.falconvpn.app.vpn.engine

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Encrypted-at-rest storage for Shadowsocks profiles. Passwords never leave native storage. */
class SecureProfileStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("falcon_secure_profiles", Context.MODE_PRIVATE)
    private val alias = "falcon_profiles_aes_gcm_v1"
    private val storageKey = "encrypted_profiles_v1"
    private val selectedKey = "selected_profile_id_v1"

    @Synchronized
    fun save(profile: ShadowsocksProfile): JSONObject {
        val all = readAll()
        val existingIndex = (0 until all.length()).firstOrNull {
            all.optJSONObject(it)?.optString("host") == profile.host &&
                all.optJSONObject(it)?.optInt("port") == profile.port &&
                all.optJSONObject(it)?.optString("name") == profile.name
        }
        val id = if (existingIndex != null) all.getJSONObject(existingIndex).getString("id") else UUID.randomUUID().toString()
        val item = JSONObject()
            .put("id", id)
            .put("name", profile.name)
            .put("host", profile.host)
            .put("port", profile.port)
            .put("method", profile.method)
            .put("password", profile.password)
            .put("protocol", "Shadowsocks")
        if (existingIndex != null) all.put(existingIndex, item) else all.put(item)
        writeAll(all)
        return metadata(item).put("saved", true).put("updated", existingIndex != null)
    }

    @Synchronized
    fun saveVless(profile: VlessProfile): JSONObject {
        val all = readAll()
        val existingIndex = (0 until all.length()).firstOrNull {
            val item = all.optJSONObject(it)
            item?.optString("protocol") == "VLESS" && item.optString("host") == profile.host &&
                item.optInt("port") == profile.port && item.optString("uuid") == profile.uuid &&
                item.optString("name") == profile.name
        }
        val id = if (existingIndex != null) all.getJSONObject(existingIndex).getString("id") else UUID.randomUUID().toString()
        val item = VlessLinkParser.toStoredJson(profile, id)
        if (existingIndex != null) all.put(existingIndex, item) else all.put(item)
        writeAll(all)
        return metadata(item).put("saved", true).put("updated", existingIndex != null)
    }

    @Synchronized
    fun list(): JSONArray {
        val result = JSONArray()
        val all = readAll()
        for (i in 0 until all.length()) result.put(metadata(all.getJSONObject(i)))
        return result
    }

    @Synchronized
    fun delete(id: String): Boolean {
        val old = readAll()
        val next = JSONArray()
        var found = false
        for (i in 0 until old.length()) {
            val item = old.getJSONObject(i)
            if (item.optString("id") == id) found = true else next.put(item)
        }
        if (found) {
            writeAll(next)
            if (prefs.getString(selectedKey, null) == id) {
                prefs.edit().remove(selectedKey).commit()
            }
        }
        return found
    }

    @Synchronized
    fun select(id: String): Boolean {
        val all = readAll()
        val exists = (0 until all.length()).any { all.optJSONObject(it)?.optString("id") == id }
        if (!exists) return false
        return prefs.edit().putString(selectedKey, id).commit()
    }

    @Synchronized
    fun selectedMetadata(): JSONObject? {
        val id = prefs.getString(selectedKey, null) ?: return null
        return list().let { profiles ->
            (0 until profiles.length()).firstNotNullOfOrNull { i ->
                profiles.optJSONObject(i)?.takeIf { it.optString("id") == id }
            }
        }
    }

    @Synchronized
    fun getSelectedForEngine(): JSONObject? {
        val id = prefs.getString(selectedKey, null) ?: return null
        return getForEngine(id)
    }

    @Synchronized
    fun getForEngine(id: String): JSONObject? {
        val all = readAll()
        for (i in 0 until all.length()) {
            val item = all.getJSONObject(i)
            if (item.optString("id") == id) return JSONObject(item.toString())
        }
        return null
    }

    private fun metadata(item: JSONObject) = JSONObject()
        .put("id", item.getString("id"))
        .put("name", item.optString("name"))
        .put("host", item.optString("host"))
        .put("port", item.optInt("port"))
        .put("method", item.optString("method"))
        .put("protocol", item.optString("protocol", "Shadowsocks"))
        .put("security", item.optString("security"))
        .put("transport", item.optString("transport"))
        .put("sni", item.optString("sni"))

    private fun readAll(): JSONArray {
        val stored = prefs.getString(storageKey, null) ?: return JSONArray()
        val packed = Base64.decode(stored, Base64.NO_WRAP)
        require(packed.size > 12) { "تعذر قراءة مخزن الكونفجات المشفر." }
        val iv = packed.copyOfRange(0, 12)
        val ciphertext = packed.copyOfRange(12, packed.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
        return JSONArray(String(cipher.doFinal(ciphertext), Charsets.UTF_8))
    }

    private fun writeAll(profiles: JSONArray) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(profiles.toString().toByteArray(Charsets.UTF_8))
        val packed = cipher.iv + encrypted
        check(prefs.edit().putString(storageKey, Base64.encodeToString(packed, Base64.NO_WRAP)).commit()) {
            "تعذر حفظ الكونفج على الجهاز."
        }
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (keyStore.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }
}

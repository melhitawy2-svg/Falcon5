package com.falconvpn.app.vpn.platform

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.ConnectivityManager
import android.net.IpPrefix
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.system.OsConstants
import androidx.core.app.NotificationCompat
import com.example.vpnstarter.MainActivity
import com.falconvpn.app.vpn.engine.SecureProfileStore
import com.falconvpn.app.vpn.engine.SingBoxConfigWriter
import io.nekohasekai.libbox.CommandServer
import io.nekohasekai.libbox.CommandServerHandler
import io.nekohasekai.libbox.ConnectionOwner
import io.nekohasekai.libbox.InterfaceUpdateListener
import io.nekohasekai.libbox.Libbox
import io.nekohasekai.libbox.LocalDNSTransport
import io.nekohasekai.libbox.NetworkInterfaceIterator
import io.nekohasekai.libbox.OverrideOptions
import io.nekohasekai.libbox.PlatformInterface
import io.nekohasekai.libbox.RoutePrefix
import io.nekohasekai.libbox.RoutePrefixIterator
import io.nekohasekai.libbox.SetupOptions
import io.nekohasekai.libbox.StringIterator
import io.nekohasekai.libbox.SystemProxyStatus
import io.nekohasekai.libbox.TunOptions
import io.nekohasekai.libbox.WIFIState
import java.net.InetAddress
import java.util.concurrent.Executors
import io.nekohasekai.libbox.NetworkInterface as BoxNetworkInterface
import io.nekohasekai.libbox.Notification as BoxNotification
import java.net.NetworkInterface as JavaNetworkInterface

/**
 * Android VPN service backed by sing-box libbox (CommandServer + PlatformInterface).
 * State is reported as CONNECTED only after libbox confirms the service started
 * (startOrReloadService returned without error, which includes opening the TUN).
 * Written against libbox 1.13.14 signatures; not yet compiled or device-tested.
 */
class FalconVpnService : VpnService(), PlatformInterface, CommandServerHandler {
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val connectivity by lazy { getSystemService(ConnectivityManager::class.java) }
    @Volatile private var commandServer: CommandServer? = null
    @Volatile private var tunPfd: ParcelFileDescriptor? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    private val store by lazy { SecureProfileStore(applicationContext) }
    private val configWriter by lazy { SingBoxConfigWriter(applicationContext) }
    private var foregroundStarted = false
    private val timerHandler = Handler(Looper.getMainLooper())
    private var sessionEndsAtMillis = 0L
    private val sessionTimer = object : Runnable {
        override fun run() {
            val remaining = sessionEndsAtMillis - System.currentTimeMillis()
            if (sessionEndsAtMillis <= 0L) return
            if (remaining <= 0L) {
                stopRealSession("انتهت مدة الجلسة المجانية (15 دقيقة).")
            } else {
                getSharedPreferences(STATUS_PREFS, MODE_PRIVATE).edit()
                    .putLong(KEY_REMAINING_SECONDS, (remaining + 999L) / 1000L).apply()
                timerHandler.postDelayed(this, 1000L)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                executor.execute { shutdown("تم إيقاف الاتصال.") }
                return START_NOT_STICKY
            }
            ACTION_START -> startConnection(startId)
            else -> {
                stopSelf(startId)
                return START_NOT_STICKY
            }
        }
        return START_NOT_STICKY
    }

    private fun startConnection(startId: Int) {
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, notification("جارٍ تجهيز اتصال Falcon VPN"))
        foregroundStarted = true
        updateState(STATE_CONNECTING, "جارٍ تجهيز الاتصال…")

        // Defense in depth: permission is normally requested by MainActivity, but the
        // service must also fail safely if it is started from a notification/system path.
        if (VpnService.prepare(this) != null) {
            failAndStop(startId, "إذن VPN غير متاح. افتح التطبيق واضغط اتصال لمنح الإذن.", STATE_NEEDS_PERMISSION)
            return
        }

        // Do not establish an empty TUN or show CONNECTED without a live engine.
        val profile = runCatching { store.getSelectedForEngine() }.getOrNull()
        if (profile == null) {
            failAndStop(startId, "حدد كونفج محفوظًا أولًا.")
            return
        }

        executor.execute {
            try {
                startEngine(profile)
                configWriter.delete() // the runtime config contains the proxy password
                updateState(STATE_CONNECTED, "تم الاتصال.")
                getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification("متصل"))
                startSessionTimerAfterEngineConnected()
            } catch (e: Throwable) {
                stopEngine()
                failAndStop(startId, e.message ?: "تعذر تشغيل محرك الاتصال.")
            }
        }
    }

    private fun startEngine(profile: org.json.JSONObject) {
        val configJson = configWriter.write(profile).readText(Charsets.UTF_8)
        synchronized(FalconVpnService::class.java) {
            if (!setupDone) {
                Libbox.setup(SetupOptions().also {
                    it.basePath = filesDir.path
                    it.workingPath = (getExternalFilesDir(null) ?: filesDir).path
                    it.tempPath = cacheDir.path
                    it.logMaxLines = 500L
                    it.debug = false
                })
                setupDone = true
            }
        }
        val server = Libbox.newCommandServer(this, this)
        commandServer = server
        server.start()
        server.startOrReloadService(configJson, OverrideOptions())
    }

    @Synchronized
    private fun stopEngine() {
        runCatching { commandServer?.closeService() }
        runCatching { commandServer?.close() }
        commandServer = null
        runCatching { tunPfd?.close() }
        tunPfd = null
        networkCallback?.let { runCatching { connectivity.unregisterNetworkCallback(it) } }
        networkCallback = null
    }

    /** Runs on the executor thread. */
    private fun shutdown(message: String) {
        stopEngine()
        stopSessionTimer()
        configWriter.delete()
        updateState(STATE_DISCONNECTED, message)
        stopForegroundCompat()
        stopSelf()
    }

    /** Safe to call from any thread, including libbox callbacks. */
    private fun shutdownAsync(message: String) {
        mainHandler.post { executor.execute { shutdown(message) } }
    }

    /** Call only after libbox reports a successfully started, working tunnel. */
    private fun startSessionTimerAfterEngineConnected() {
        sessionEndsAtMillis = System.currentTimeMillis() + FREE_SESSION_MILLIS
        getSharedPreferences(STATUS_PREFS, MODE_PRIVATE).edit()
            .putLong(KEY_SESSION_ENDS_AT, sessionEndsAtMillis)
            .putLong(KEY_REMAINING_SECONDS, FREE_SESSION_SECONDS)
            .apply()
        timerHandler.removeCallbacks(sessionTimer)
        timerHandler.post(sessionTimer)
    }

    private fun stopSessionTimer() {
        timerHandler.removeCallbacks(sessionTimer)
        sessionEndsAtMillis = 0L
        getSharedPreferences(STATUS_PREFS, MODE_PRIVATE).edit()
            .remove(KEY_SESSION_ENDS_AT).putLong(KEY_REMAINING_SECONDS, 0L).apply()
    }

    private fun stopRealSession(reason: String) = shutdownAsync(reason)

    private fun failAndStop(startId: Int, message: String, state: String = STATE_ERROR) {
        stopSessionTimer()
        configWriter.delete()
        updateState(state, message)
        if (foregroundStarted) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.notify(NOTIFICATION_ID, notification(message))
        }
        stopForegroundCompat()
        stopSelf(startId)
    }

    private fun notification(message: String): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FalconVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle("Falcon VPN")
            .setContentText(message.take(180))
            .setContentIntent(openApp)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setOngoing(foregroundStarted)
            .setOnlyAlertOnce(true)
            .addAction(0, "إيقاف", stop)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "اتصال Falcon VPN", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun updateState(state: String, message: String) {
        getSharedPreferences(STATUS_PREFS, MODE_PRIVATE).edit()
            .putString(KEY_STATE, state)
            .putString(KEY_MESSAGE, message)
            .putLong(KEY_UPDATED_AT, System.currentTimeMillis())
            .apply()
    }

    @Suppress("DEPRECATION")
    private fun stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE)
        else stopForeground(true)
        foregroundStarted = false
    }

    override fun onRevoke() {
        shutdownAsync("تم إلغاء إذن VPN من إعدادات أندرويد؛ تم إيقاف الخدمة بأمان.")
        super.onRevoke()
    }

    override fun onDestroy() {
        stopEngine()
        stopSessionTimer()
        configWriter.delete()
        if (foregroundStarted) stopForegroundCompat()
        super.onDestroy()
    }

    // ---------------- CommandServerHandler ----------------
    override fun getSystemProxyStatus(): SystemProxyStatus = throw UnsupportedOperationException()
    override fun serviceReload() = shutdownAsync("طلب المحرك إعادة التحميل؛ تم إيقاف الاتصال.")
    override fun serviceStop() = shutdownAsync("أوقف المحرك الاتصال.")
    override fun setSystemProxyEnabled(isEnabled: Boolean) {}
    override fun writeDebugMessage(message: String?) {}

    // ---------------- PlatformInterface ----------------
    override fun autoDetectInterfaceControl(fd: Int) {
        if (!protect(fd)) throw Exception("تعذر حماية المقبس (protect) من نفق VPN.")
    }

    override fun usePlatformAutoDetectInterfaceControl(): Boolean = true
    override fun clearDNSCache() {}
    override fun includeAllNetworks(): Boolean = false
    override fun underNetworkExtension(): Boolean = false
    override fun useProcFS(): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q
    override fun localDNSTransport(): LocalDNSTransport? = null
    override fun readWIFIState(): WIFIState? = null
    override fun sendNotification(notification: BoxNotification) {}
    override fun systemCertificates(): StringIterator = StringArray(emptyList())

    override fun findConnectionOwner(
        ipProtocol: Int, sourceAddress: String?, sourcePort: Int,
        destinationAddress: String?, destinationPort: Int
    ): ConnectionOwner = throw Exception("البحث عن مالك الاتصال غير مدعوم.")

    private fun pickUnderlying(): Network? {
        @Suppress("DEPRECATION")
        val candidates = connectivity.allNetworks.mapNotNull { n ->
            val c = connectivity.getNetworkCapabilities(n) ?: return@mapNotNull null
            if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) ||
                c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return@mapNotNull null
            val rank = when {
                c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> 0
                c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> 1
                c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> 2
                else -> 3
            }
            val validated = if (c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) 0 else 10
            Triple(n, rank + validated, c)
        }
        return candidates.minByOrNull { it.second }?.first
    }

    private fun reportDefault(listener: InterfaceUpdateListener) {
        val network = pickUnderlying()
        val name = network?.let { connectivity.getLinkProperties(it)?.interfaceName }
        if (network == null || name == null) {
            listener.updateDefaultInterface("", -1, false, false)
            return
        }
        val index = runCatching { JavaNetworkInterface.getByName(name)?.index ?: 0 }.getOrDefault(0)
        val caps = connectivity.getNetworkCapabilities(network)
        val metered = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED) == false
        listener.updateDefaultInterface(name, index, metered, false)
    }

    override fun startDefaultInterfaceMonitor(listener: InterfaceUpdateListener) {
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) = reportDefault(listener)
            override fun onLost(network: Network) = reportDefault(listener)
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) = reportDefault(listener)
        }
        networkCallback = callback
        connectivity.registerNetworkCallback(
            NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build(), callback
        )
        reportDefault(listener)
    }

    override fun closeDefaultInterfaceMonitor(listener: InterfaceUpdateListener) {
        networkCallback?.let { runCatching { connectivity.unregisterNetworkCallback(it) } }
        networkCallback = null
    }

    override fun getInterfaces(): NetworkInterfaceIterator {
        val javaIfaces = JavaNetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
        val out = mutableListOf<BoxNetworkInterface>()
        @Suppress("DEPRECATION")
        for (network in connectivity.allNetworks) {
            val lp = connectivity.getLinkProperties(network) ?: continue
            val caps = connectivity.getNetworkCapabilities(network) ?: continue
            val name = lp.interfaceName ?: continue
            val ji = javaIfaces.find { it.name == name } ?: continue
            val box = BoxNetworkInterface()
            box.name = name
            box.index = ji.index
            box.dnsServer = StringArray(lp.dnsServers.mapNotNull { it.hostAddress?.substringBefore('%') })
            box.type = when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> Libbox.InterfaceTypeWIFI
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> Libbox.InterfaceTypeCellular
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> Libbox.InterfaceTypeEthernet
                else -> Libbox.InterfaceTypeOther
            }
            runCatching { box.mtu = ji.mtu }
            box.addresses = StringArray(ji.interfaceAddresses.map { it.address.hostAddress.orEmpty().substringBefore('%') + "/" + it.networkPrefixLength })
            var flags = 0
            if (ji.isUp) flags = flags or OsConstants.IFF_UP or OsConstants.IFF_RUNNING
            if (ji.isLoopback) flags = flags or OsConstants.IFF_LOOPBACK
            if (ji.isPointToPoint) flags = flags or OsConstants.IFF_POINTOPOINT
            if (ji.supportsMulticast()) flags = flags or OsConstants.IFF_MULTICAST
            box.flags = flags
            box.metered = !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
            out.add(box)
        }
        return InterfaceArray(out.iterator())
    }

    private fun RoutePrefixIterator.collect(): List<RoutePrefix> {
        val l = mutableListOf<RoutePrefix>(); while (hasNext()) l.add(next()); return l
    }

    private fun StringIterator.collect(): List<String> {
        val l = mutableListOf<String>(); while (hasNext()) l.add(next()); return l
    }

    override fun openTun(options: TunOptions): Int {
        if (VpnService.prepare(this) != null) throw Exception("إذن VPN غير ممنوح.")
        val builder = Builder().setSession("Falcon VPN").setMtu(options.getMTU())
        val v4 = options.getInet4Address().collect()
        val v6 = options.getInet6Address().collect()
        v4.forEach { builder.addAddress(it.address(), it.prefix()) }
        v6.forEach { builder.addAddress(it.address(), it.prefix()) }
        if (options.getAutoRoute()) {
            builder.addDnsServer(options.getDNSServerAddress().value)
            val r4 = options.getInet4RouteAddress().collect() + options.getInet4RouteRange().collect()
            val r6 = options.getInet6RouteAddress().collect() + options.getInet6RouteRange().collect()
            if (r4.isNotEmpty()) r4.forEach { builder.addRoute(it.address(), it.prefix()) }
            else if (v4.isNotEmpty()) builder.addRoute("0.0.0.0", 0)
            if (r6.isNotEmpty()) r6.forEach { builder.addRoute(it.address(), it.prefix()) }
            else if (v6.isNotEmpty()) builder.addRoute("::", 0)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                (options.getInet4RouteExcludeAddress().collect() + options.getInet6RouteExcludeAddress().collect()).forEach {
                    builder.excludeRoute(IpPrefix(InetAddress.getByName(it.address()), it.prefix()))
                }
            }
            options.getIncludePackage().collect().forEach { runCatching { builder.addAllowedApplication(it) } }
            options.getExcludePackage().collect().forEach { runCatching { builder.addDisallowedApplication(it) } }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) builder.setMetered(false)
        val pfd = builder.establish() ?: throw Exception("تعذر إنشاء واجهة VPN (ربما تم سحب الإذن).")
        tunPfd = pfd
        return pfd.fd
    }

    private class StringArray(items: List<String>) : StringIterator {
        private val it = items.iterator()
        private val size = items.size
        override fun hasNext(): Boolean = it.hasNext()
        override fun len(): Int = size
        override fun next(): String = it.next()
    }

    private class InterfaceArray(private val it: Iterator<BoxNetworkInterface>) : NetworkInterfaceIterator {
        override fun hasNext(): Boolean = it.hasNext()
        override fun next(): BoxNetworkInterface = it.next()
    }

    override fun onBind(intent: Intent): IBinder? = super.onBind(intent)

    companion object {
        @Volatile private var setupDone = false
        const val ACTION_START = "com.falconvpn.app.vpn.START"
        const val ACTION_STOP = "com.falconvpn.app.vpn.STOP"
        const val STATUS_PREFS = "falcon_vpn_runtime_status"
        const val KEY_STATE = "state"
        const val KEY_MESSAGE = "message"
        const val KEY_UPDATED_AT = "updated_at"
        const val KEY_SESSION_ENDS_AT = "session_ends_at"
        const val KEY_REMAINING_SECONDS = "remaining_seconds"
        private const val FREE_SESSION_SECONDS = 15L * 60L
        private const val FREE_SESSION_MILLIS = FREE_SESSION_SECONDS * 1000L
        const val STATE_DISCONNECTED = "DISCONNECTED"
        const val STATE_NEEDS_PERMISSION = "NEEDS_PERMISSION"
        const val STATE_CONNECTING = "CONNECTING"
        const val STATE_CONNECTED = "CONNECTED"
        const val STATE_ERROR = "ERROR"
        private const val CHANNEL_ID = "falcon_vpn_connection"
        private const val NOTIFICATION_ID = 7101
    }
}
